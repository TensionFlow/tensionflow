<?php header("Content-Type:text/html;charset=utf-8");

$job = $_POST['job'];
$speed = $_POST['speed'];
$tone = $_POST['tone'];
$kinds = $_POST['kinds'];

$mysql_link = mysql_connect($localhost, $root, $apmsetup) or die (mysql_error());
mysql_select_db($user);

mysql_query("INSERT INTO user_info_2(job, speed, tone, kinds) 
values('$job', '$speed', '$tone', '$kinds')");
?>

<script Type = 'Text/Javascript' Language='javascript'>
<!--
alert("저장되었습니다.");
document.location = "result.html";
//-->
</script>