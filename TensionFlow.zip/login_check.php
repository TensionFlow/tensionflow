<?php header("Content-Type:text/html;charset=utf-8");
session_start();
$id=$_POST['id'];
$pw=$_POST['pw'];
$mysqli=mysqli_connect("localhost", "root", "apmsetup", "user");

$check="SELECT * FROM user_info WHERE userid='$id'";
$result=$mysqli->query($check);
if($result -> num_rows==1){
    $row=$result -> fetch_array(MYSQLI_ASSOC);
    if($row['userpw']==$pw){
        $_SESSION['userid']=$id;
        if(isset($_SESSION['userid']))
        {
            header('Location: ./main.php');
        }
        else{
            echo "save session failed";
        }
    }
    else{
        echo "wrong id or pw";
    }
}
else{
    echo "wrong id or pw";
}
?>