<?php header("Content-Type:text/html;charset=utf-8");
    session_start();
    if(!isset($_SESSION['userid']))
    {
        header ('Location: ./login.html');
    }

echo "<script>
alert(\"로그인이 되었습니다.\");
window.open('./index2.html', 'width=600, height=600, top=100, left=100');
</script>";

?>