<?php header("Content-Type:text/html;charset=utf-8");
$id=$_POST['id'];
$pw=$_POST['pw'];
$pwc=$_POST['pwc'];
$name=$_POST['name'];
$gender=$_POST['gender'];
$birth=$_POST['birth'];

if($pw!=$pwc)
{
    echo "Password and Confirm Password are different.";
    echo "<a href=sign_in.html>back page</a>";
    exit();
}

if($id==NULL || $pw==NULL || $name==NULL || $gender==NULL || $birth==NULL)
{
    echo "<script>
    alert(\"빈칸을 채워주세요.\");
    window.open('./sign_in.html', 'width=600, height=600, top=100, left=100');
    </script>";
    exit();
}

$mysqli=mysqli_connect("localhost", "root", "apmsetup", "user");

$check="SELECT *from user_info WHERE userid='$id'";
$result=$mysqli->query($check);
if($result->num_rows==1)
{
    echo "<script>
    alert(\"중복되는 아이디입니다.\");
    window.open('./sign_in.html','width=600, height=600, top=100, left=100');
    </script>";
    exit();
}

$signup=mysqli_query($mysqli,"INSERT INTO user_info (userid,userpw,name,gender,birth)
VALUES ('$id', '$pw', '$name', '$gender', '$birth')");
if($signup)
{
    echo "<script>
    alert(\"회원가입이 되었습니다.\");
    window.open('./login.html', 'width=600, height=600, top=100, left=100');
    </script>";
    exit();
}

?>